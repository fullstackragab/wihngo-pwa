import { Heart, Bird } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";

interface FeedCardProps {
  moment: {
    id: string;
    birdName: string;
    birdSpecies: string;
    caption: string;
    mediaUrl: string;
    mediaType: "photo" | "video";
    birdId: string;
  };
  onBirdClick: (birdId: string) => void;
  onSupportClick: (birdId: string, birdName: string) => void;
}

export function FeedCard({ moment, onBirdClick, onSupportClick }: FeedCardProps) {
  return (
    <Card className="overflow-hidden border-border/50 shadow-sm mb-4">
      {/* Bird header */}
      <div 
        className="flex items-center gap-3 p-4 cursor-pointer hover:bg-accent/30 transition-colors"
        onClick={() => onBirdClick(moment.birdId)}
      >
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
          <Bird className="w-5 h-5 text-primary" />
        </div>
        <div>
          <p className="font-medium text-foreground">{moment.birdName}</p>
          <p className="text-sm text-muted-foreground">{moment.birdSpecies}</p>
        </div>
      </div>

      {/* Media */}
      <div className="relative aspect-square bg-muted">
        {moment.mediaType === "photo" ? (
          <img
            src={moment.mediaUrl}
            alt={moment.caption}
            className="w-full h-full object-cover"
          />
        ) : (
          <video
            src={moment.mediaUrl}
            className="w-full h-full object-cover"
            controls
            playsInline
          />
        )}
      </div>

      {/* Caption and actions */}
      <div className="p-4 space-y-3">
        <p className="text-foreground leading-relaxed">{moment.caption}</p>
        
        <Button
          onClick={() => onSupportClick(moment.birdId, moment.birdName)}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
        >
          <Heart className="w-4 h-4 mr-2" />
          Support {moment.birdName}
        </Button>
      </div>
    </Card>
  );
}

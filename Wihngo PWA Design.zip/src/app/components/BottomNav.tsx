import { Bird, User, Plus } from "lucide-react";

interface BottomNavProps {
  activeTab: "feed" | "profile" | "upload";
  onTabChange: (tab: "feed" | "profile" | "upload") => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
      <div className="max-w-lg mx-auto flex items-center justify-around h-16">
        <button
          onClick={() => onTabChange("feed")}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeTab === "feed" ? "text-primary" : "text-muted-foreground"
          }`}
        >
          <Bird className="w-6 h-6" />
          <span className="text-xs mt-1">Feed</span>
        </button>

        <button
          onClick={() => onTabChange("upload")}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeTab === "upload" ? "text-primary" : "text-muted-foreground"
          }`}
        >
          <Plus className="w-6 h-6" />
          <span className="text-xs mt-1">Share</span>
        </button>

        <button
          onClick={() => onTabChange("profile")}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeTab === "profile" ? "text-primary" : "text-muted-foreground"
          }`}
        >
          <User className="w-6 h-6" />
          <span className="text-xs mt-1">Profile</span>
        </button>
      </div>
    </div>
  );
}

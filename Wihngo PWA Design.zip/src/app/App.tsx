import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "../../utils/supabase/info";
import { Onboarding } from "./components/Onboarding";
import { TopBar } from "./components/TopBar";
import { BottomNav } from "./components/BottomNav";
import { FeedCard } from "./components/FeedCard";
import { BirdProfile } from "./components/BirdProfile";
import { SupportFlow } from "./components/SupportFlow";
import { UserProfile } from "./components/UserProfile";
import { UploadFlow } from "./components/UploadFlow";
import { OurPrinciples } from "./components/OurPrinciples";
import { HowFeesWork } from "./components/HowFeesWork";
import { CreateBirdProfile } from "./components/CreateBirdProfile";
import { toast, Toaster } from "sonner";

type Screen =
  | { type: "onboarding" }
  | { type: "feed" }
  | { type: "bird-profile"; birdId: string }
  | { type: "support"; birdId: string; birdName: string }
  | { type: "profile" }
  | { type: "upload" }
  | { type: "principles" }
  | { type: "fees" }
  | { type: "create-bird" };

export default function App() {
  const [screen, setScreen] = useState<Screen>({ type: "onboarding" });
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string>("");
  const [feed, setFeed] = useState<any[]>([]);
  const [userBirds, setUserBirds] = useState<any[]>([]);
  const [supportHistory, setSupportHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const supabase = createClient(
    `https://${projectId}.supabase.co`,
    publicAnonKey
  );

  const serverUrl = `https://${projectId}.supabase.co/functions/v1/make-server-a8b70ba1`;

  // Check for existing session
  useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    const { data } = await supabase.auth.getSession();
    if (data?.session?.access_token) {
      setAccessToken(data.session.access_token);
      setUser(data.session.user);
      setScreen({ type: "feed" });
      loadFeed();
    }
  };

  // Load feed
  const loadFeed = async () => {
    try {
      const response = await fetch(`${serverUrl}/feed`, {
        headers: {
          Authorization: `Bearer ${publicAnonKey}`,
        },
      });
      const data = await response.json();
      
      // Create mock feed data for demo
      const mockFeed = [
        {
          id: "1",
          birdId: "bird-1",
          birdName: "Sunny",
          birdSpecies: "Yellow Canary",
          caption: "Morning song practice! Sunny loves greeting the sunrise with beautiful melodies. 🎵",
          mediaUrl: "https://images.unsplash.com/photo-1654181920354-5c4add3989a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW5hcnklMjBiaXJkfGVufDF8fHx8MTc2Njc1NjMyNnww&ixlib=rb-4.1.0&q=80&w=1080",
          mediaType: "photo" as const,
        },
        {
          id: "2",
          birdId: "bird-2",
          birdName: "Kiwi",
          birdSpecies: "Green Parakeet",
          caption: "Kiwi discovered his reflection today and can't stop chatting with his 'new friend'! 💚",
          mediaUrl: "https://images.unsplash.com/photo-1705603476601-2d406ec86b07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJha2VldCUyMHBldHxlbnwxfHx8fDE3NjY3NTYzMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
          mediaType: "photo" as const,
        },
        {
          id: "3",
          birdId: "bird-3",
          birdName: "Ruby",
          birdSpecies: "Cardinal",
          caption: "First time trying blueberries! Ruby approved. 🫐",
          mediaUrl: "https://images.unsplash.com/photo-1518992028580-6d57bd80f2dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGJpcmR8ZW58MXx8fHwxNzY2NzU2MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080",
          mediaType: "photo" as const,
        },
      ];
      
      setFeed(mockFeed);
    } catch (error) {
      console.error("Error loading feed:", error);
    }
  };

  // Load user's birds
  const loadUserBirds = async () => {
    if (!accessToken) return;
    
    try {
      const response = await fetch(`${serverUrl}/user/birds`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setUserBirds(data.birds || []);
    } catch (error) {
      console.error("Error loading user birds:", error);
    }
  };

  // Load support history
  const loadSupportHistory = async () => {
    if (!accessToken) return;
    
    try {
      const response = await fetch(`${serverUrl}/user/support-history`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setSupportHistory(data.transactions || []);
    } catch (error) {
      console.error("Error loading support history:", error);
    }
  };

  // Handle signup
  const handleSignup = async (email: string, password: string, name: string) => {
    setLoading(true);
    try {
      // Create user via server
      const signupResponse = await fetch(`${serverUrl}/signup`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password, name }),
      });

      if (!signupResponse.ok) {
        const error = await signupResponse.json();
        toast.error(error.error || "Signup failed");
        setLoading(false);
        return;
      }

      // Sign in
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast.error(error.message);
        setLoading(false);
        return;
      }

      setAccessToken(data.session.access_token);
      setUser(data.session.user);
      setScreen({ type: "feed" });
      loadFeed();
      toast.success("Welcome to Wihngo!");
    } catch (error) {
      console.error("Signup error:", error);
      toast.error("Something went wrong");
    }
    setLoading(false);
  };

  // Handle logout
  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setAccessToken("");
    setScreen({ type: "onboarding" });
    toast.success("Logged out");
  };

  // Handle bird click
  const handleBirdClick = (birdId: string) => {
    setScreen({ type: "bird-profile", birdId });
  };

  // Handle support click
  const handleSupportClick = (birdId: string, birdName: string) => {
    setScreen({ type: "support", birdId, birdName });
  };

  // Handle support complete
  const handleSupportComplete = () => {
    setScreen({ type: "feed" });
    toast.success("Support sent successfully!");
    loadFeed();
  };

  // Handle create bird
  const handleCreateBird = async (bird: any) => {
    if (!accessToken) return;

    try {
      const response = await fetch(`${serverUrl}/bird`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          ...bird,
          imageUrl: "https://images.unsplash.com/photo-1713019280736-94bcc35360dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFsbCUyMGJpcmQlMjBjYXJlfGVufDF8fHx8MTc2Njc1NjMyNXww&ixlib=rb-4.1.0&q=80&w=1080",
        }),
      });

      if (response.ok) {
        toast.success("Bird profile created!");
        setScreen({ type: "profile" });
        loadUserBirds();
      } else {
        const error = await response.json();
        toast.error(error.error || "Failed to create profile");
      }
    } catch (error) {
      console.error("Error creating bird:", error);
      toast.error("Something went wrong");
    }
  };

  // Render current screen
  const renderScreen = () => {
    if (screen.type === "onboarding") {
      return <Onboarding onComplete={handleSignup} />;
    }

    if (screen.type === "feed") {
      return (
        <div className="min-h-screen bg-background pb-20">
          <TopBar title="Wihngo" showLogo />
          
          <div className="max-w-lg mx-auto p-4">
            {feed.length === 0 ? (
              <div className="text-center py-12 space-y-3">
                <p className="text-muted-foreground">No moments yet</p>
                <p className="text-sm text-muted-foreground">
                  Check back soon for bird updates
                </p>
              </div>
            ) : (
              feed.map((moment) => (
                <FeedCard
                  key={moment.id}
                  moment={moment}
                  onBirdClick={handleBirdClick}
                  onSupportClick={handleSupportClick}
                />
              ))
            )}
          </div>

          <BottomNav
            activeTab="feed"
            onTabChange={(tab) => {
              if (tab === "profile") {
                loadUserBirds();
                loadSupportHistory();
                setScreen({ type: "profile" });
              } else if (tab === "upload") {
                loadUserBirds();
                setScreen({ type: "upload" });
              } else {
                setScreen({ type: "feed" });
              }
            }}
          />
        </div>
      );
    }

    if (screen.type === "bird-profile") {
      // Mock bird data
      const mockBird = {
        id: screen.birdId,
        name: screen.birdId === "bird-1" ? "Sunny" : screen.birdId === "bird-2" ? "Kiwi" : "Ruby",
        species: screen.birdId === "bird-1" ? "Yellow Canary" : screen.birdId === "bird-2" ? "Green Parakeet" : "Cardinal",
        description: "A lovely bird who brings joy to everyone around.",
        imageUrl: screen.birdId === "bird-1" 
          ? "https://images.unsplash.com/photo-1654181920354-5c4add3989a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW5hcnklMjBiaXJkfGVufDF8fHx8MTc2Njc1NjMyNnww&ixlib=rb-4.1.0&q=80&w=1080"
          : screen.birdId === "bird-2"
          ? "https://images.unsplash.com/photo-1705603476601-2d406ec86b07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJha2VldCUyMHBldHxlbnwxfHx8fDE3NjY3NTYzMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          : "https://images.unsplash.com/photo-1518992028580-6d57bd80f2dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGJpcmR8ZW58MXx8fHwxNzY2NzU2MzI1fDA&ixlib=rb-4.1.0&q=80&w=1080",
        totalSupport: 23,
        ownerId: "owner-1",
      };

      return (
        <BirdProfile
          bird={mockBird}
          moments={[]}
          onBack={() => setScreen({ type: "feed" })}
          onSupport={handleSupportClick}
        />
      );
    }

    if (screen.type === "support") {
      return (
        <SupportFlow
          birdId={screen.birdId}
          birdName={screen.birdName}
          onBack={() => setScreen({ type: "feed" })}
          onComplete={handleSupportComplete}
        />
      );
    }

    if (screen.type === "profile") {
      return (
        <>
          <UserProfile
            onBack={() => setScreen({ type: "feed" })}
            onCreateBird={() => setScreen({ type: "create-bird" })}
            onViewBird={handleBirdClick}
            onViewPrinciples={() => setScreen({ type: "principles" })}
            onViewFees={() => setScreen({ type: "fees" })}
            onLogout={handleLogout}
            userBirds={userBirds}
            supportHistory={supportHistory}
          />
          <BottomNav
            activeTab="profile"
            onTabChange={(tab) => {
              if (tab === "feed") {
                setScreen({ type: "feed" });
              } else if (tab === "upload") {
                loadUserBirds();
                setScreen({ type: "upload" });
              }
            }}
          />
        </>
      );
    }

    if (screen.type === "upload") {
      return (
        <UploadFlow
          onBack={() => setScreen({ type: "feed" })}
          onComplete={() => {
            setScreen({ type: "feed" });
            toast.success("Moment shared!");
            loadFeed();
          }}
          userBirds={userBirds}
        />
      );
    }

    if (screen.type === "principles") {
      return (
        <OurPrinciples
          onBack={() => setScreen({ type: "profile" })}
        />
      );
    }

    if (screen.type === "fees") {
      return (
        <HowFeesWork
          onBack={() => setScreen({ type: "profile" })}
        />
      );
    }

    if (screen.type === "create-bird") {
      return (
        <CreateBirdProfile
          onBack={() => setScreen({ type: "profile" })}
          onCreate={handleCreateBird}
        />
      );
    }

    return null;
  };

  return (
    <>
      {renderScreen()}
      <Toaster position="top-center" />
    </>
  );
}
import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-a8b70ba1/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint
app.post("/make-server-a8b70ba1/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });
    
    if (error) {
      console.log(`Error creating user during signup: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }
    
    return c.json({ user: data.user });
  } catch (error) {
    console.log(`Error in signup endpoint: ${error}`);
    return c.json({ error: "Signup failed" }, 500);
  }
});

// Get feed of bird moments
app.get("/make-server-a8b70ba1/feed", async (c) => {
  try {
    const moments = await kv.getByPrefix("moment:");
    return c.json({ moments: moments || [] });
  } catch (error) {
    console.log(`Error fetching feed: ${error}`);
    return c.json({ error: "Failed to fetch feed" }, 500);
  }
});

// Get bird profile
app.get("/make-server-a8b70ba1/bird/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const bird = await kv.get(`bird:${id}`);
    
    if (!bird) {
      return c.json({ error: "Bird not found" }, 404);
    }
    
    // Get bird's moments
    const moments = await kv.getByPrefix(`moment:bird:${id}`);
    
    return c.json({ bird, moments: moments || [] });
  } catch (error) {
    console.log(`Error fetching bird profile: ${error}`);
    return c.json({ error: "Failed to fetch bird profile" }, 500);
  }
});

// Create bird profile
app.post("/make-server-a8b70ba1/bird", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    );
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (!user?.id) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const { name, species, description, imageUrl, walletAddress } = await c.req.json();
    const birdId = crypto.randomUUID();
    
    const bird = {
      id: birdId,
      name,
      species,
      description,
      imageUrl,
      walletAddress,
      ownerId: user.id,
      createdAt: new Date().toISOString(),
      totalSupport: 0
    };
    
    await kv.set(`bird:${birdId}`, bird);
    await kv.set(`user:${user.id}:bird:${birdId}`, birdId);
    
    return c.json({ bird });
  } catch (error) {
    console.log(`Error creating bird profile: ${error}`);
    return c.json({ error: "Failed to create bird profile" }, 500);
  }
});

// Create moment
app.post("/make-server-a8b70ba1/moment", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    );
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (!user?.id) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const { birdId, caption, mediaUrl, mediaType } = await c.req.json();
    const momentId = crypto.randomUUID();
    const timestamp = Date.now();
    
    const moment = {
      id: momentId,
      birdId,
      caption,
      mediaUrl,
      mediaType,
      userId: user.id,
      createdAt: new Date().toISOString(),
      timestamp
    };
    
    await kv.set(`moment:${timestamp}:${momentId}`, moment);
    await kv.set(`moment:bird:${birdId}:${momentId}`, moment);
    
    return c.json({ moment });
  } catch (error) {
    console.log(`Error creating moment: ${error}`);
    return c.json({ error: "Failed to create moment" }, 500);
  }
});

// Record support transaction
app.post("/make-server-a8b70ba1/support", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    );
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (!user?.id) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const { birdId, amount, platformFee, txHash } = await c.req.json();
    const transactionId = crypto.randomUUID();
    
    const transaction = {
      id: transactionId,
      birdId,
      userId: user.id,
      amount,
      platformFee,
      txHash,
      createdAt: new Date().toISOString(),
    };
    
    await kv.set(`transaction:${transactionId}`, transaction);
    await kv.set(`user:${user.id}:transaction:${transactionId}`, transactionId);
    
    // Update bird's total support
    const bird = await kv.get(`bird:${birdId}`);
    if (bird) {
      bird.totalSupport = (bird.totalSupport || 0) + amount;
      await kv.set(`bird:${birdId}`, bird);
    }
    
    return c.json({ transaction });
  } catch (error) {
    console.log(`Error recording support: ${error}`);
    return c.json({ error: "Failed to record support" }, 500);
  }
});

// Get user's birds
app.get("/make-server-a8b70ba1/user/birds", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    );
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (!user?.id) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const birdIds = await kv.getByPrefix(`user:${user.id}:bird:`);
    const birds = [];
    
    for (const birdId of birdIds || []) {
      const bird = await kv.get(`bird:${birdId}`);
      if (bird) {
        birds.push(bird);
      }
    }
    
    return c.json({ birds });
  } catch (error) {
    console.log(`Error fetching user birds: ${error}`);
    return c.json({ error: "Failed to fetch user birds" }, 500);
  }
});

// Get user's support history
app.get("/make-server-a8b70ba1/user/support-history", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    );
    
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (!user?.id) {
      return c.json({ error: "Unauthorized" }, 401);
    }
    
    const transactionIds = await kv.getByPrefix(`user:${user.id}:transaction:`);
    const transactions = [];
    
    for (const txId of transactionIds || []) {
      const transaction = await kv.get(`transaction:${txId}`);
      if (transaction) {
        transactions.push(transaction);
      }
    }
    
    return c.json({ transactions });
  } catch (error) {
    console.log(`Error fetching support history: ${error}`);
    return c.json({ error: "Failed to fetch support history" }, 500);
  }
});

Deno.serve(app.fetch);